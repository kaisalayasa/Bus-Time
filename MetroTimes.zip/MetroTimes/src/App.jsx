
import './App.css'
import TimeCard from './timeCard'
function App() {


  return (
    <>
     <TimeCard location='Macalester' id='17366'></TimeCard>
     <TimeCard location='Home'id='53362'></TimeCard>
    </>
  )
}

export default App
